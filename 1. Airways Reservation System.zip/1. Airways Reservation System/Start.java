import java.lang.*;
import classes.*;
import interfaces.*;
import java.util.*;
import jFrame.*;

public class Start
{
	public static void main(String args[])
	{
		Login l1 = new Login();
		l1.setVisible(true);
	}
}